import { Decimal } from './depend/decimal.js';
// setTimeout
const fn = a => console.log(a);
console.log(typeof fn);
console.log(typeof fn(2));
// const promisel = Promise.resolve(123)
// console.log(promisel);
// setTimeout(promisel,500)
console.log(setTimeout(fn,500)); 

//逻辑运算符  能被转换为false的值有null, 0, NaN, 空字符串 ("")和undefined
const fn1 = a => a;
const value = '';
const result = value && fn1(value)
console.log('result',result);

// 运算符 in
const trees1 = {"redwood": 2, "bay": 0, "cedar": 3, "oak": 8, "maple": 5}
const trees = new Array("redwood", "bay", "cedar", "oak", "maple"); 
trees.unshift(trees.pop()); 
console.log(trees);
const filterTree = trees.filter(v => {
  console.log(v);
  return v === 'oak' || v === 'bay'
})
console.log(filterTree);
console.log(0 in trees)
console.log("redwood" in trees1)

// apply call bind
const arr = ['a','b']
const ele = [1,2,3]
arr.push.apply(arr,ele)
arr.push.call(arr,...ele)
console.log(arr);

//this在一个方法中指调用的对象。
const obj1 = {
  x: 24,
  getX: function(){
    console.log('x',this.x);
    return this.x
  }
}
const obj2 = {
  x:25,
  y: 'obj2'
}
let fn2 = obj1.getX.bind(obj1)  //生成新的指定this的函数
fn2() // -> x 24
obj1.getX() // -> x 24
obj1.getX.apply(obj2)  // -> x 25
obj1.getX.call(obj2) // -> x 25

//web API -- fecth

//Generator  暂缓执行
function* f(){
  console.log('执行了');
}
const generator = f()

setTimeout(()=> generator.next(),2000)


let  zu = 5;
const objCn = { a:{ c:{}}, b:1}
console.log(objCn.toString());
console.log(Object.prototype.toString.call(objCn));
console.log([zu],typeof [zu]);
console.log([zu][0]);



let str1 = "172.16.170.53"
let str2 = "172.16.49.62"
console.log(str2 > str1);

console.log(typeof [1,2,3] === 'object');

let group = 'live'
let arr12 = [1,2,3,4,5]
console.log(arr12.map( item => {
  return {
    cc:item,
    go:group
  }
}))

obj3 = null
console.log(JSON.stringify(obj3),typeof JSON.stringify(obj3));
console.log(Object.keys(obj3));

arr11 = [1,5,6,5,4]
arr11.map(item => {
  item = item + item;
})
// console.log(arr11.splice(2,1));
console.log(arr11);

arr12 =  [1,5,6,5,4]
arr12.splice(2,0,8)
console.log(arr12);

let a = 'aa'
console.log(parseInt(a,10));

let obj = {a:1,b:2}
console.log(obj['c'] || 0);

let str55 = '#10#'
console.log(str55.split('#'));

let operatorList=['!=', '<' ,'<=' ,'=' ,'>', '>=' ,'不为null','不包含','为null','包含','开头为','结尾为'] 
let sttr = "Model%10%UniServer R4900 G5"
console.log(sttr.replace(/\%\d+\%/g, '不包含')); 
sttr.replace(/%\d%/g, text => {
  console.log(text);
  return operatorList[+text.split('%')[1]-1]
})
console.log(sttr);

strg = 'live-5'
console.log(strg.split('live-')[1]);

stt = { aa: 11,bb: 22}
console.log(stt.cc === undefined);

let bitList = Array.from({length: 16}, (_, index) => ({'value':index,'select':false}));
console.log(bitList);

console.log(parseInt('00040', 10));

console.log( false || true );

a = [{a:1},{b:5}]
a[0] = {b: 1}
console.log(a);
console.log(a[5] ? 1 : 2);

let hh = '100.004'
console.log(Number(hh) > 100);

console.log(/^0|[1-9][0-9]{0,4}$/.test('-1'));
console.log(/^(0|[1-9][0-9]*)$/.test('-1'));

console.log(/^[0]$/.test('-1'));

console.log(Array.from({a:1,b:2},(key,value)=>value));

let arrr = [[]]
arrr[1] = 5
console.log(arrr);

let ssstr = '065536'
console.log(ssstr[0] === '0');

let iii = []
console.log(iii[0]);
iii[1] = 1
iii[2] = 2
console.log(iii[0]);


const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];
const result1 = words.filter(word => word.length > 6);
console.log(result1.length);
console.log(words.length);

console.log(Number('123e5'));

[].forEach(item => console.log(1))

console.log(/^[0134][0-9]{4}$/.test('00010'));

console.log(JSON.parse(false));

[].includes()

let len = 25
console.log(`${len}$jiayi等于26`);


console.log(/\$(normal|minor|major|critical)/.test('$normalrtr'));

let strr = '$normalrtr'.replace(/\$(normal|minor|major|critical)/g, match => {
    console.log(match);
    return match.replace(/\$/,'')
})
console.log(strr);

let cc = undefined 
console.log(typeof cc);
if(cc) console.log(1);

console.log(32767*(1000000000 * 1.1)/1000000000);

function multiply(a, b) {
  const precision = 10; // 设置精度为10位小数，根据需要进行调整
  // 将科学计数法字符串转换为浮点数
  const num1 = parseFloat(a);
  const num2 = parseFloat(b);
  // 将浮点数转换为指定精度的字符串
  const str1 = num1.toFixed(precision);
  const str2 = num2.toFixed(precision);
  // 将字符串转换为浮点数，并进行乘法计算
  const result = parseFloat(str1) * parseFloat(str2);
  // 返回计算结果
  return result;
}

function multiply1(a, b) {
  // 创建 Decimal 对象
  const num1 = new Decimal(a);
  const num2 = new Decimal(b);
  // 进行乘法计算
  const result = num1.times(num2);
  // 返回计算结果的字符串表示
  return result.toString();
}

console.log(multiply(99.99999,2147493647));
console.log(multiply1(99.99999,2147493647));

let obh = { a: 1}
console.log(obh['b']);

a=[1,2,3]

a.map((item,index)=>{
  item = 2
})
console.log(a);

let b={aa: {cc:1},bb:2,cc:3}
let kk = b.aa
delete b.aa
console.log(kk);


let dfdf = NaN
console.log(typeof dfdf);
if(dfdf) console.log(1);

let obj615= {}; // 空对象
for (let key in obj615) {
  console.log(key); // 不会输出任何内容
}

obj = {
  a:'null',
  b: ()=>true
}
console.log(obj.b,typeof obj.b);

const promise = new Promise(() => 1)
console.log(promise); 

console.log('4900G5'.includes('G5'))

console.log(''.split(';'));

const regex1 = /风扇[1-6]\uff08(前|后)\uff09存在故障/g
const regex2 = /Fan[1-6]\((front|rear)\) is faulty/g
item = "风扇5（前）存在故障"
item1 ="Fan3(front) is faulty"
console.log(item.search(regex1));
console.log(item1.search(regex2));
console.log(+item1[item1.indexOf('Fan') + 3]);

obj={title: "28-更换NVMe_M.2_SSD转接卡",url:1}
obj.title = obj.title.replace(/_/g, ' ')
console.log(obj);


let text = null
console.log(text === (null || undefined || '') ? '--' : text);

// 负向断言
let regex = /(?<!i)fist(?! sms)/gi;
const testString = "检测应答文件缺少特定字段'ifist-install-disk'，请使用模板下载，Fist SMS一样的"
console.log(testString.match(regex)); 
console.log(testString.replace(regex, 'userver'));


let regexrr = /(^|[^i])fist(?! sms)/ig;
let krt = /(?<!i)fist(?! sms)/ig
// let reft = /\b(?!i)fist(?!\ssms)\b/gi;
let stt = 'FIST大大大ifist的封面分了手fiST SMS检控方Fistdfafefefist'
let sty = 'FIST login FIST SmS iFisTdfw fistsms fist sms fist'
console.log(sty.replace(regexrr, '$1unisystem'));
console.log(stt.replace(regexrr, '$1unisystem'));
console.log(sty.replace(krt, 'unisystem'));
console.log(stt.replace(krt, 'unisystem'));

let fays = 'cpu2存在故障;cpu1存在故障'
console.log(fays.replace(/\u5b58\u5728\u6545\u969c/g,'*'));
console.log(fays.split('|'));

console.log(Object.keys({}).length)
Object.keys({}).forEach(item => {
  console.log(1);
})

let dtt = 'dwwdIKO#21321'
console.log(/[A-Z]/.test(dtt));

const a = document.createElement('a')
console.log(a.download);

let devices = [{a:1},{a:2},3]
let newDe = devices.filter(item => item.a && item.a > 1)
console.log(newDe);
devices[1]['b'] = 2
console.log(newDe);

console.log(['a'] == ![]);
console.log(null == undefined);

// let  var变量提升
var a = [];
for (var i = 0; i < 10; i++) {
  a[i] = function () {
    console.log(i);
  };
}
a[6](); // 10

const getDeepKeysValue = (obj, keys) => keys.split('.').reduce((init, key) => init[key], obj)
let objj = {a:1, b:2}
let keys = 'a.b'
console.log(getDeepKeysValue(objj,keys));


let as = [{a:1, b:2},{a:2, b:3}]
console.log(as.reduce((arr,item) => [...arr,item.a],[]));
console.log(as);

let randomValue = { name: "Lydia" }
randomValue = 23
if (!typeof randomValue === "string") {
	console.log("It's not a string!")
} else {
	console.log("Yay it's a string!")
}

let user = {a:1,authority:['user']}
let isAdminRole = user && Array.isArray(user.authority) && user.authority.includes('user')

console.log(''.split('-')[0]);
console.log(Number(''));

let authorityList = ["user", "system", "device", "power", "deploy", "component", "energy", "erasure", "alarm", "guest"]
authorityList.splice(authorityList.indexOf("energy"), 1)
console.log(authorityList);

let aa = -1
console.log(Math.abs(aa));

let bb = 'TRUE'
console.log(bb?.toLocaleLowerCase() === 'true');

function setTime(flag) {
  let count = 0
  if(!flag) {
    console.log(time, typeof time);
    clearInterval(time)
  }
  if(flag){
    let time = setInterval(() => {
      console.log(count);
      if(count < 2) count++;
      if(count === 2) { 
        clearInterval(time)
        time = null
      }
    },500)
  }
}
setTime(true)
setTime(false)

let bit = 10101010
console.log((parseInt(bit) & (1 << 1)));

const timestamp = new Date().getTime();
console.log(timestamp); // 输出当前时间戳




async function getData() {
  if(true) {
    await setTimeout(() => {
      console.log('1');
    }, 1000);
  }
  console.log('2');
}
getData();

{
  let data = [1,2,3,4,5]
  console.log(data.entries().next().value);
  for (const iterator of data.entries()) {
    console.log(iterator);
  }
}


let a= null
console.log(Math.abs(a || -1));

Promise.resolve(1).then(2).then(console.log); // 1
Promise.reject(1).then(2,2).then(console.log,console.log); // 1


{
  let a = '安装中'
  let b = '安装成功'
  let c = '安装失败'
  console.log(a<b);
  console.log(a<c);
  console.log(b>c);
  // b>c>a
}

{
  let text = '{IP}'
  console.log(new RegExp(text, 'g'));
  console.log(parseInt(text));
}

{
  function* createIterator() {
    for (let index = 0; index < array.length; index+n) {
      yield array.slice(index,n+index)
    }
  }
  const array = [1,2,3,4,5,6,7,8,9,10]
  const n = 2
  const iterator = createIterator()
  console.log('iterator', [...iterator]);
}

{
  console.log('script start')
  async function async1() {
      await async2() 
      console.log('async1 end')
  }
  async function async2() {
      console.log('async2 end')
  }
  async1()
  setTimeout(function() {
      console.log('setTimeout')
  }, 0)
  new Promise(resolve => {
      console.log('Promise')
  resolve()
  })
  .then(function() {
      console.log('promise1')
  })
  .then(function() {
      console.log('promise2')
  })
  console.log('script end')
}

{
  console.log(/G6|G7/.test('H3C UniServer 4900 G6')); 
}

{
  console.log((new Date().getTime() - 24 * 60 * 60 * 1000).getFullYear());
}

{
  function A(){
    return new Promise((resolve, reject) =>{
        setTimeout(() => {      
            resolve()
            console.log('异步A完成')
        }, 1000)
    })
  }
  function B(){
      return new Promise((resolve, reject) =>{
          setTimeout(() => {
              console.log('异步B完成')
              resolve()
          }, 500)
          
      })
  }
  function C(){
      setTimeout(() => {
          console.log('异步C完成')
      }, 100)
  }
  A()
  .then(() => { 
      return B()
  })
  .then(() => {
      C()
  })
}

{
  async function example() {
    console.log('Before await');
    await new Promise(resolve => setTimeout(() => {
      console.log('Inside Promise');
      resolve();
    }, 1000)); // 模拟异步操作
    setTimeout(() => { console.log('Inside setTimeout'); }, 0);
    console.log('After await');
  }
  console.log('Start');
  new Promise(resolve => setTimeout(() => {console.log('outside Promise'); resolve(); }, 1000));
  example();
  console.log('End');
}

{
  var str = 'abc'
  str += 1
  var test = typeof str
  console.log(test, typeof test);
  if(test.length == 6){
      test.sign = 'typeof的返回结果可能为String'
  }
  console.log(test.sign);
}

{
  let a = new String('123')
  a.sign = "123"
  console.log(a.sign);
  console.log(a, typeof a);
}

{
  const cache = { '10': 20 } 
  const memoize = (fn) =>
  (
    (cache = Object.create(null)) =>
    (arg) =>
    {
      console.log(cache)
      return cache[arg] || (cache[arg] = fn(arg))
    }
  )()
  const fn = (x) => x * 2
  const memoizedFn = memoize(fn)
  const memoizedFn1 = memoize(fn)
  console.log(memoizedFn(10));
  console.log(memoizedFn(20));
  console.log(memoizedFn1(10));
}

{
  const { a: aa, b } = { a: 3, b: 4 };
  console.log(aa, b);
}

{
  const obj = {
    a: 1,
    b: { c: 2, d: 3, e: { f: 4 }, x: [1, 2] },
    g: [1, 2, 3, { i: 5 }, [2, 4]],
    h: null
  }
  function expandeObj(obj) {
    const result = {}
    for(let key in obj) {
      expand(key, obj[key])
    }
    function expand(key, value) {
      if(value === null) {
        return
      } else if(typeof value === 'object' && !Array.isArray(value)) {
        for(let k in value) {
          let newKey = key + '.' + k
          expand(newKey, value[k])
        }
      } else if(Array.isArray(value)) {
        for(let i = 0; i < value.length; i++) {
          let newKey = key+ '[' + i +']'
          expand(newKey, value[i])
        }
      } else {
        result[key] = value
      }
    }
    return result
  }
  console.log(expandeObj(obj));
}

{
  function Person() {
    this.name = 'zhangsan'
    this.age = 18
    console.log(this instanceof Person);
  }
  const person = new Person()
}

{
  const promise1 = new Promise((resolve, reject) => resolve('success'))
  const promise2 = new Promise((resolve, reject) => resolve(promise1))
  promise2.then(res => console.log(res))
}

{
  let a = Function.prototype.apply.call(Math.floor, undefined, [1.75])
  console.log(a);
  let b = Function.prototype.call.apply(Math.floor, [undefined, 1.75])
  console.log(b);
}





