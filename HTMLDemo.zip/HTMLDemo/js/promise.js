/*数组方法*/

//slice 数组内部元素 浅拷贝
let animals = ['ant', 'bison', 'camel', 'duck', 'elephant']
console.log(animals.slice(2, -1));
animals = [{ color: 'black', is: false}, ...animals]
let newAnimal = animals.slice();
animals[0].color = 'white'
console.log(newAnimal);

// splice 插入删除 修改原数组
splice(start, deleteCount, item1, item2, itemN)

// reduce 累加  数组扁平 计算数组元素出现次数 去重
reduce(function(previousValue, currentValue, currentIndex, array) { /* … */ }, initialValue)
  // 管道
  const double = x => x * 2
  const three =  x => x * 3
  const pipe = (...functions) => inintValue => functions.reduce((acc,fn) => fn(acc), inintValue)
  const mutiply6 = pipe(double, three)
  console.log(mutiply6(6));

  // promise顺序执行

//shift unshift

/*Promise --对象，代表一个异步操作的最终完成或失败以及其结果值*/
  /**
   * Promise约定
   * 在本轮事件循环运行完成之前，回调函数是不会被调用的。
   * 即使异步操作已经完成（成功或失败），在这之后通过then()添加的回调函数也会被调用。
   * 通过多次调用then()可以添加多个回调函数，它们会按照插入顺序进行执行。
   * Promise三种状态：
   * 待定（pending）：初始状态，既没有被兑现，也没有被拒绝。
   * 已兑现（fulfilled）：意味着操作成功完成。
   * 已拒绝（rejected）：意味着操作失败
   */

  /* 两个特性 三种状态*/ 
  const promise = doSomething().then(sucessCallback,failureCallback) //即代表了doSomething完成，也代表了sucessCallback,failureCallback的完成

  // 链式调用、catch后可继续链式操作
  doSomething().then(result => doSomethingelse(result))
  .then(newresult =>doSomethingthird(newresult))
  .then(finalResult => console.log(`Got the final result: ${finalResult}`))
  .catch(failureCallback)  // catch(failureCallback) 是 then(null, failureCallback) 的缩略形式

  //链式过程中抛出异常时会顺着Promise链寻找下一个onRejected失败回调函数或者catch()指定的回调函数
  try{
    let result = syncDoSomething();
    let newResult = syncDoSomethingElse(result);
    let finalResult = syncDoThirdThing(newResult);
    console.log(`Got the final result: ${finalResult}`);
  } catch(error){
    failureCallback(error)
  }
  // async/await 语法糖
  async function foo(){
    try{
      let result = await doSomething();
      let newResult = await doSomethingElse(result);
      let finalResult = await doThirdThing(newResult);
      console.log(`Got the final result: ${finalResult}`);
    } catch(error){
      failureCallback(error)
    }
  }

  //拒绝事件

  //旧式回调API中创建Promise  -- new Promise()构造器 -> 包装不支持 promise（返回值不是 Promise）的函数
  const promisel = new Promise((resove,reject) => {
    setTimeout(()=> {
      resove('foo')
      console.log(resove('foo'));
      console.log(promisel);
    },500)
  })
  const promisel1 = promisel.then(value => {
    console.log(value)
  })
  const promisel2 = promisel.then(
    {aa:11}
  )
  console.log('promisel',promisel);
  console.log('promisel1',promisel1);
  console.log('promisel2',promisel2);

  const promisel3 = Promise.resolve(123)
  console.log('promisel3',promisel3);
  promisel3.then((value)=>{
    console.log(value);
  })

  const original = Promise.resolve(123)
  const cast = Promise.resolve(original)
  cast.then(value => console.log('value: ' + value))
  console.log('original === cast ? ' + (original === cast));

  const waitTime = ms => new Promise(resolve => setTimeout(()=>resolve(),ms))
  waitTime(2000).then(()=>console.log(4))

  const wait1 = ms => new Promise(resolve => {
    console.log('wait1',resolve,typeof resolve);
    setTimeout(resolve, ms)
  });
  const wait2 = ms => new Promise(resolve => {
    console.log('wait2',resolve,typeof resolve);
    console.log(resolve(),typeof resolve());
    setTimeout(resolve(), ms)  //这里为啥没报错，settimeout参数要求是回调函数
  });
  wait1().then(() => console.log(4));
  wait2().then(() => console.log(5));
  Promise.resolve().then(() => console.log(2)).then(() => console.log(3));
  console.log(1); // 1, 2, 3, 4  

  

  //静态方法  
     // all失败后不再继续 - allsetted等待所有promise敲定   any只返回成功  race成功或失败立即回调  
     // reject resolve返回一个带着给定值解析过的 Promise 对象，如果参数本身就是一个 Promise 对象，则直接返回这个 Promise 对象。
  //实例方法  catch then finally

  // 语法糖 async 返回一个promise对象，对象要么由返回值被解决，要么由抛出的异常被拒绝
/*函数 -- 方法  -- 闭包*/





