// path 模块
const path = require('path')
const result = path.join(__dirname, '../public/uploads')
const result1 = path.resolve('foo/bar', 'tmp/file/', '..', 'a', '../', 'b')
const result3 = path.resolve('foo/bar', '/tmp/file/', '..', 'a/../subfile');
console.log(result);
console.log(result1);
console.log(result3);

// fs 文件系统
const fs = require('fs')
fs.readFile('./package.json', (err, data) => {
  console.log('异步读取文件');
})
fs.writeFile('./package.json', 'hello world', (err) => {
  console.log('异步写入文件');
})

// http 模块
const http = require('http') 
const server = http.createServer((req, res) => {
  res.end('hello world')
  res.on('finish', () => {
  })
})