Array.isArray()  // 方法用于判断一个值是否为数组。
Array.from() // 方法可以将类数组对象转化为数组。
// 生成一个[0,1,2,...,99]的数组
console.log(new Array(100).fill(0).map((d,i)=>i));
console.log(Array.from(new Array(100).fill(0),(x,i)=>x+i));
console.log(Array.from({length:100},(x,i)=>i));
Array.of() // 方法可以创建一个数组实例，可变参数为数组元素。
Array.of(1,2,3); // [1,2,3]

Array.slice() // 截取数组的一部分，返回一个新数组，不改变原数组。