// Numbers
// 非数字
Number.isNaN()
// 整数
Number.isIntegar()
console.log(Number.isFinite(2.3));
// 有限数
Number.isFinite() 
console.log(Number.isFinite(0/0))
// 定点表示法格式化数值 小数点后面位数 四舍五入
Number.toFix()
// 字符串
Number.toString()

// Math
// 向下取整数
Math.floor()
// 四舍五入
Math.round()
// 向上取整数
Math.ceil()
// 绝对值
Math.abs()
// 0-1 随机数
Math.random()