
// 方法可以返回一个字符串中特定索引处的字
String.chartAt() 
// 拼接字符串
String.cancat()
// 是否包含某字符串
String.includes()
// 指定字符串的索引
String.indexOf()
// 正则匹配，返回匹配结果 数组[]
String.match()
// 重复一个字符串
String.repeat()
// 替换字符串中的一部分
String.replace()
// 正则匹配，返回匹配结果的索引值
String.search()
// 截取字符串
String.split()
// 大小写
String.toLowerCase(); String.toUpperCase()
// 截断字符串 包含起始不包含结束
String.subString(); String.slice()
// 移除两端空白符
String.trim()



