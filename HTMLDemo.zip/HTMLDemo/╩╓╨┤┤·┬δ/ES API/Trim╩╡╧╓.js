function trim() {
  let str = this
  if(typeof str !== 'string') {
    throw new Error('The "this" value must be a string')
  }
  return str.replace(/^\s+|\s+$/g, '')
}

let str = '    Hello World!  '
console.log(str.trim());