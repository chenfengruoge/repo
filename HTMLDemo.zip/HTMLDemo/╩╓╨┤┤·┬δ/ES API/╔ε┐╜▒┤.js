// 1.基本检查，判断对象类型
// 2.循环引用检测, 内部已经拷贝过的对象，直接返回
// 3.特殊对象处理
// 4.循环引用处理 新对象存入hash中
// 5.递归拷贝属性
function cloneDeep(obj, hash = new WeakMap()) {
  if(obj === null || typeof obj !== 'object') { // 处理常见的对象及数组类型
    return obj  
  }

  if(hash.has(obj)) return hash.get(obj)

  // 增加处理内置Date、regExp、Error、Function等类型
  if(obj instanceof Date) return new Date(obj)
  if(obj instanceof RegExp) return new RegExp(obj)

  const newObj = Array.isArray(obj) ? [] : {}

  hash.set(obj, newObj)

  // 递归拷贝属性
  for(let key in obj) {
    // for...in 遍历对象属性,会遍历自身属性以及原型链上的属性，使用hasOwnProperty可过滤原型链上的属性以及对象本身中不可枚举的属性
    if(obj.hasOwnProperty(key)) {
      newObj[key] = cloneDeep(obj[key], hash)
    }
  }
}

{
  function deepEqual(obj1, obj2, hash = new WeakMap()) {
    // 1.严格比值
    if( obj1 === obj2 ) return true
  
    // 2.类型校验，排除基本类型及null
    if(typeof obj1 !== 'object' || obj1 === null || typeof obj2 !== 'object' || obj2 === null) return false
  
    // 3.处理循环引用
    if(hash.get(obj1) && hash.get(obj1) === obj2) return true
    hash.set(obj1, obj2)

    // 4.原型比较
    if(Object.getPrototypeOf(obj1) !== Object.getPrototypeOf(obj2)) return false
  
    // 4.属性值长度比较
    if(Object.keys(obj1).length !== Object.keys(obj2).length) return false
  
    // 5.遍历属性递归比较
    for(let key in obj1) {
      if(!Object.keys(obj2).includes(key) || !deepEqual(obj1[key], obj2[key], hash)) {
        return false
      }    
    }

    return true
  }

  const obj1 = {
    name: 'Alice',
    age: 25,
    hobbies: ['reading', 'hiking'],
    address: {
        city: 'Wonderland',
        zip: '12345'
    },
    birthDate: new Date(),
    pattern: /abc/g,
    circularRef: {}
  };
  const obj2 = {
    name: 'Alice',
    age: 25,
    hobbies: ['reading', 'hiking'],
    address: {
        city: 'Wonderland',
        zip: '12345'
    },
    birthDate: new Date(obj1.birthDate.getTime()), // 克隆日期
    pattern: new RegExp(obj1.pattern), // 克隆正则表达式
    circularRef: {}
  };
  // 创建循环引用
  obj1.circularRef.self = obj1;
  obj2.circularRef.self = obj2;
  console.log(deepEqual(obj1, obj2)); // 输出: true
}

{
  // 比较常用的拷贝方法
  // Object.assign() -- 1.仅第一层 2.null和undefine会被忽略 3.原型属性以及不可枚举的不行
  // JSON.parse(JSON.stringify()) -- Function不行，内置对象类型会被序列化失效，循环引用报错

  // constructor可以被修改，一般不需要用它进行类别判断
  // null 原型上不存在constructor属性
  let obj = []
  console.log(obj.constructor);
  console.log(Object.prototype.toString.call(obj));
  console.log(null.constructor);

  // for...in 遍历对象属性,会遍历自身属性以及原型链上的属性，使用hasOwnProperty可过滤原型链上的属性以及对象本身中不可枚举的属性
  Object.prototype.customMethod = function () {
    console.log('cuatomMethod');
  }
  const newObj = {
    name: 'wr'
  }
  for(let key in newObj) {
    if(newObj.hasOwnProperty(key)){
      console.log(key);
    }
  }
  for(let key in [5,6,7]) {
    // for...in 遍历数组时，key是数组的索引，字符串类型
    console.log(key, typeof key);
    console.log([5,6,7][key]);
  }

  //defineProperties 定义及修改属性
  const object1 = {};
  Object.defineProperties(object1, {
    property1: {
      value: 42,
      writable: true, // 默认false，与属性关联的值可以使用赋值运算符更改
      enumerable: true, //默认false，是否可枚举
      configurable: true //默认false，是否可修改属性描述符及删除属性
    },
    property2: {},
  });
  console.log(object1.property1);
  for(let key in object1) {
    console.log(key);
  }
}
