function Box(value) {
  this.value = value;
}
Box.prototype.getValue = function() {
  return this.value;
}

let box = new Box(10);
console.log(box.getValue()); // Output: 10

// 原型的灵活性
Box.prototype.getValue = function() {
  return this.value * 2;
}

console.log(box.getValue()); // Output: 20
