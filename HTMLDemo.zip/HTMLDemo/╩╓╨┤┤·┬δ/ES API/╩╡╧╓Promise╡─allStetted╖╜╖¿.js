/**
  allSettled方法（等待所有结果兑现promise，带有所有promise结果的对象数组）
  all方法（有一个拒绝状态返回拒绝promise，给出第一个拒绝的原因）
  any方法 (等待第一个兑现的promise，如果没有兑现返回包含拒绝原因的数组)
  race方法（由第一个promise状态敲定返回promise的状态） 超时、比较
  reject方法 （返回一个拒绝的promise）
  resolve方法 （用于创建一个promise，用给定值解决）
 **/
function myAllSettled(promises) {
  return new Promise((resolve) => { //resolve为executor函数的参数，用以更改promise的状态
    let count = 0;
    let values = [];
    let collect = (index, status) => value => {
      const prop = status === 'fulfilled' ? 'value' : 'reason';
      values[index] = { status, [prop]: value };
      ++count === promises.length && resolve(values);
    }
    promises.forEach((promise, index) => {
      // onFulfilled、onRejected为promise状态改变的回调函数
      if(promise instanceof Promise) {
        promise.then(collect(index, 'fulfilled'), collect(index, 'rejected'));
      } else { // 非promise对象,包装成promise并以值解决
        collect(index, 'fulfilled')(promise);
      }
    })
  })
}
function myAllSettled1(promises) {
  const onFulfilled = value => ({ 'status': 'fulfilled', value });
  const onRejected = reason => ({ 'status': 'reject', reason });
  return Promise.all(promises.map(promise => Promise.resolve(promise).then(onFulfilled, onRejected)));
}
{
  const p1 = new Promise((resolve, reject) => {
    return resolve(1);
  })
  const p2 = Promise.resolve(2);
  const p3 = 3
  const p4 = Promise.reject(3)
  Promise.allSettled([p1, p2, p3, p4]).then(res => console.log(res))
  myAllSettled([p1, p2, p3, p4]).then(res => console.log(res))
  myAllSettled1([p1, p2, p3, p4]).then(res => console.log(res))
}

/* 使用asnyc/await实现promise.all方法 */
function myAll(promises) {
  return new Promise((resove,reject) => {
    let rejectFlag = false;
    let count = 0;
    let values = [];
    const collect = async(promise) => {
      try {
        let value = await promise
        values.push(value);
        ++count === promises.length && resove(values);
      } catch(reason) {
        rejectFlag = true;
        reject(reason);
      }
    }
    if(promises.length === 0) {
      resove(promises);
    } else {
      for (let index = 0; index < promises.length; index++) {
        if(rejectFlag) break;
        collect(Promise.resolve(promises[index]));
      }
    }
  })
}

{
  const a = Promise.resolve(1);
  const b = Promise.resolve(2);
  const c = Promise.reject(3);
  Promise.all([]).then(res => console.log('Allres',res)).catch(err => console.log('err',err));
  myAll([]).then(res => console.log('myAllres',res)).catch(err => console.log('err',err));
}

/* 实现asnyc/await */
function resolveAfter2Seconds(x) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(x);
    }, 2000);
  })
}

async function f1() {
  let x = await resolveAfter2Seconds(10);
  console.log(x);
} 
