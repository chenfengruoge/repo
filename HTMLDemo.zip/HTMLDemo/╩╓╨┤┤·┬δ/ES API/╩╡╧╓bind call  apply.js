// 三者区别 
// call() 方法使用一个指定的 this 值和单独给出的一个或多个参数来调用一个函数。接受一个参数列表
// apply() 方法 区别call是接受的是一个包含多个参数的数组。
// bind() 方法 区别call是在于它会返回一个新的函数实例，这个新的函数实例可以稍后再调用
Function.prototype.myCall = function(context, ...args) {
  // this指向需要执行的函数  context为原函数指定的上下文(this新指向的部分)
  // console.log(typeof this);
  if(typeof this !== 'function'){
    throw('非函数调用')
  }
  // 上下文需要考虑没有传参的情况
  context = context || window
  //将需要执行的函数挂载到上下文新属性上并进行执行
  let fn = Symbol('fn')
  context[fn] = this
  let result = context[fn](...args)
  delete context[fn]
  return result
}

Function.prototype.myApply = function (context, args) {
  if(typeof this !== 'function') {
    throw('非函数调用')
  }
  context = context || window
  const fn = Symbol('fn')
  context[fn] = this
  const result = context[fn](...args)
  delete context[fn]
  return result
}

//1.0 基础版 暂不考虑参数的校验
Function.prototype.myBind1 = function (context) {
   let self = this 
   return function () {
     return self.apply(context)  //更改this指向,可能会有返回值需要返回，加上return
   }
}

//2.0 柯里化，支持参数分段式传入
Function.prototype.myBind2 = function(context, ...args) {
  let self = this
  return function (...subargs) {
    return self.apply(context, args.concat(subargs))
  }
}

//3.0 作为构造函数，不管是原始函数还是重新bing绑定的函数，内部this永远指向的是创建的实例，因此不用更改this指向了
Function.prototype.myBind3 = function(context, ...args) {
  let self = this
  return function (...subargs) {
    return self.apply( this instanceof self ? this : context, args.concat(subargs)) //return 是因为原始函数存在有返回值的情况
  }
}

//4.0 维护原始函数的原型链
Function.prototype.myBind3 = function(context, ...args) {
  let self = this
  let fn = function (...subargs) {
    return self.apply( this instanceof self ? this : context, args.concat(subargs))
  }
  // fn.prototype = this.prototype // 粗暴版，更改原型对象指向
  let fnBound = function () {} // 使用中间变量
  fnBound.prototype = this.prototype
  fn.prototype = new fnBound()
  return fn
}


function Product(name, price){
  this.name = name  // this指向正在创建的新对象实例
  this.price = price
}
function Food(name, price){
  Product.myCall(this,name,price)
  // Product.apply(this,[name,price])
  // let product = Product.bind(this,name,price)
  // product()
  this.category = 'food'
}
let cheese = new Food('cheese', 5)
console.log(cheese.name);

function foo(x,y,z) {
  this.name = 'foo'
  console.log(this instanceof foo);
  console.log(this.num, x+y+z);
  return x+y+z
}
let obj = {
  num: 6
}
foo(1,2,3)
new foo(1,2,3)
const foo1 = foo.bind(obj,1,2)
const foo2 = foo.myBind3(obj,1,2)
console.log(new foo1(3))
console.log(new foo2(3))

function printName(name) {
  console.log(name);
}
console.log(new printName('wr'));
