function* helloGenerator() {
  yield 'hello';
  yield 'world';
  return 'ending';
}
const h = helloGenerator(); // 返回一个内部指针，指向内部状态

h.next();// { value: 'hello', done: false }

{
  let a = [0, 1, [1, 2, [3, 4, 5]]]
  function* demo(a) {
    for(let i = 0; i< a.length; i++) {
      if(Array.isArray(a[i])) {
        yield* demo(a[i]) //yield* 表示自动遍历Generator函数
      } else {
        yield a[i]
      }
    }
  }
  for (let f of demo(a)) {
    console.log(f);
  }
}

{
  function* f() {
    for(var i = 1; true; i++) {
      var reset = yield i;
      if(reset) { i = -1};
    }
  }

  var g = f();
  console.log(g.next());
  console.log(g.next(true));
}

{
  // 对象默认的遍历器生成函数就是它的Symbol.iterator属性， 执行这个函数就会返回一个遍历器对象
  // Generator 函数就是一个遍历器生成函数
  var myIterable =  {}
  myIterable[Symbol.iterator] = function* () {
    yield 1;
    yield 2;
    yield 3;
  }
  // for..of Array.from 扩展... 解构赋值
  console.log([...myIterable]);
  console.log(myIterable[Symbol.iterator]() === myIterable);
}

{
  function* g() {
    yield 1;
  } // 生成函数
  var i = g(); // 遍历器对象的Symbol.iterator属性表示遍历器生成函数，执行后返回自己
  console.log(i[Symbol.iterator]() === i);
}

//next throw return 方法
// next()是将上阶段执行的yield表达式替换成一个值
  // 相当于将 let result = yield x + y
  // 替换成 let result = 输入值;
// throw()是将上阶段执行的yield表达式替换成一个throw语句
  // 相当于将 let result = yield x + y
  // 替换成 let result = throw(new Error('出错了'))
// return()是将上阶段执行的yield表达式替换成一个return语句
  // 相当于将 let result = yield x + y
  // 替换成 let result = return 2;
{
  const g = function* (x, y) {
    let result = yield x + y;
    return result;
  }
  const gen = g(1, 2);
  console.log(gen.next());

  //yield表达式本身没有返回值，或者说总是返回undefined
  console.log(gen.next()); //{ value: undefined, done: true }
}


//yied* 可以自动遍历可迭代的对象

// 一个自定义的可迭代对象
{
  const array = {
    value: [1, 2, 3],
    [Symbol.iterator]: function() {
      let index = 0;
      return { // 实现next方法,返回一个带有value和done属性的对象
        next: () => {
          if(index < this.value.length) {
            return { value: this.value[index++], done: false }
          } else {
            return { value: undefined, done: true }
          }
        }
      }
    }
  }
  console.log(...array);
}

{
  let fetch = require('node-fetch');
  function* gen() {
    let url = 'https://api.github.com/users/github';
    let result = yield fetch(url);
  }

  let g = gen();
  let result = g.next();
  result.value.then(data => {
    console.log(data);
    return data.json();
  }).then(data => {
    console.log(data);
  })
}
