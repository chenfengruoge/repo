// 构造函数 二进制数据的连续内存空间
let arrayBuffer = new ArrayBuffer(1024); //1024字节的内存空间
// 输出："[object ArrayBuffer]"
console.log(Object.prototype.toString.call(arrayBuffer)); 
// typeArray视图 是对数组缓冲区的视图，它允许数组缓冲区的内容可以被视为同一数据类型的数组
let view = new Uint8Array(arrayBuffer); 
// dataView视图  允许数组缓冲区的内容可以被视为不同的数据类型的数组  
let dataView = new DataView(arrayBuffer); 
// 具体实例方法看MDN
