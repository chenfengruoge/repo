const a = [1,2,3,4,5];
console.log(a instanceof Object);
console.log(1 instanceof Number);
console.log(null instanceof Object);
console.log(undefined instanceof Object);
console.log(undefined instanceof undefined);
// 基本类型 对象 null undefined
function MyInstanceOf(value, construtor) {
  // 排除基本类型、undefined 和 null; construtor 也一样
  if(value === null || value === undefined || typeof value !== 'object') return false;
  // 向上查找原型
  let proto = Object.getPrototypeOf(value);
  while(true) {
    if(proto === null) return false;
    if(proto === construtor.prototype) return true;
    proto = Object.getPrototypeOf(proto);
  }
}
console.log(Object.getPrototypeOf(1));

