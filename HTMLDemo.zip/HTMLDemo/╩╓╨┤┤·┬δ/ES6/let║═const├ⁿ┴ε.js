// var 变量提升- 声明之前使用
// let 与 var 的区别在于
//   - 作用域不同，let 只在块级作用域内有效，而 var 在函数作用域或者全局作用域内有效。
//   - 变量提升，声明之前可以使用。
//   - 不能重复声明，let 不允许在同一作用域内重复声明同一变量。
//   - 暂时性死区，let 命令会在脚本开始执行之前创建变量，但是不能访问，直到脚本开始执行，这就是暂时性死区。
// 作用域概念  块级作用域  
// for循环实例
// for循环有一个特别之处，就是设置循环变量的那部分是一个父作用域，而循环体内部是一个单独的子作用域
let a = []
for(var i = 0; i < 10; i++){
  a[i] = function() {
    console.log(i);
  }
}
a[6]() // 10

let view = []
for (let i = 0; i !== 10; ++i) view[i] = i + i
console.log(view);

// let 暂时性死区tdz 代码块内let命令声明变量之前，该变量都是不可用的
var tem = 123
if(true) {
  tem = 456
  let tem
}

// 死区导致typeof不再是百分百安全操作
if(true) {
  typeof x //报错
  let x
}
typeof y // undedined

// 块级作用域  
// es5 只有全局作用域以及函数作用域
var temp = new Date()
function f() {
  console.log(temp); //内部变量变量提升取代外部变量
  if(false) {
    var temp = "hello world"
  }
}
f() // undefined

// let实际上为 JavaScript 新增了块级作用域。
{ let insane = "Hello World" }
console.log(insane); //报错

// 匿名立即执行函数
(function name(params) {
  
}())

// 块级作用域与函数声明
function f() {
  console.log('outside');
}
(function() {
  if(false) {
    function f() {console.log('inside')} // es5 函数声明回提升到函数头部
  }
  f() //es6也报错 允许浏览器兼容老代码，也可提升到函数头部。因此最好将函数声明写成函数表达式
}())

// 块级作用域必须有大括号
// if(true) let x = 1 // 无大括号语法报错
if(true) {
  function name(params) {
    
  }
  let x = 1
}

// const 多数规则与let一致
// const 声明变量为常量 本质是要保证 变量所指向的内存地址所保存的数据不得改动

// 顶层window和global对象的属性  与  全局变量
var m = 1;
console.log(global.m)
console.log(globalThis.m);
let n = 2;
console.log(global.n)
console.log(globalThis.n);
