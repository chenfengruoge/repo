// AMD CommonJS ES6
// require 运行时加载
// export 编译时加载