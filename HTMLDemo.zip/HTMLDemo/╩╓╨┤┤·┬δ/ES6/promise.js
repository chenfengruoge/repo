class MyPromise {
  constructor(executor) {
    this.state = 'pending';
    this.value = undefined;
    this.reason = undefined;
    this.onFulfilledCallbacks = [];
    this.onRejectedCallbacks = [];

    const resolve = (value) => {
      if (this.state === 'pending') {
        if(value instanceof MyPromise) {
          return value.then(resolve, reject);
        }
        this.state = 'fulfilled';
        this.value = value;
        this.onFulfilledCallbacks.forEach(fn => fn());
      }
    }

    const reject = (reason) => {
      if (this.state === 'pending') {
        this.state = 'rejected';
        this.reason = reason;
        this.onRejectedCallbacks.forEach(fn => fn());
      }
    }

    try {
      executor(resolve, reject);
    } catch (e) {
      reject(e);
    }
  }

  then (onFulfilled, onRejected) {
    onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : value => value;
    onRejected = typeof onRejected === 'function' ? onRejected : reason => { throw reason };
    const newPromise = new MyPromise((resolve, reject) => {
      if (this.state === 'fulfilled') {
        setTimeout(() => {
          try {
            const x = onFulfilled(this.value);
            resolvePromise(newPromise, x, resolve, reject);
          } catch (e) {
            reject(e);
          }
        }, 0)
      }
      if (this.state === 'rejected') {
        setTimeout(() => {
          try {
            const x = onRejected(this.reason);
            resolvePromise(newPromise, x, resolve, reject);
          } catch (e) {
            reject(e);
          }
        }, 0);
      }
      if (this.state === 'pending') {
        this.onFulfilledCallbacks.push(() => {
          setTimeout(() => {
            try {
              const x = onFulfilled(this.value);
              resolvePromise(newPromise, x, resolve, reject);
            } catch (e) {
              reject(e);
            }
          }, 0)
        });
        this.onRejectedCallbacks.push(() => {
          setTimeout(() => {
            try {
              const x = onRejected(this.reason);
              resolvePromise(newPromise, x, resolve, reject);
            } catch (e) {
              reject(e);
            }
          }, 0)
        });
      }
    })
    return newPromise;
  }

  catch (onRejected) {
    return this.then(null, onRejected);
  }

  static resolve (value) {
    if (value instanceof MyPromise) {
      return value;
    }
    return new MyPromise(resolve => resolve(value))
  }

  static reject (reason) {
    return new MyPromise((resolve, reject) => reject(reason))
  }
}

function resolvePromise (newPromise, x, resolve, reject) {
  console.log(x, typeof x, newPromise);
  if (newPromise === x) { // 处理循环引用
    return reject(new TypeError('Chaining cycle detected for promise #<Promise>'))
  }
  if(x && (typeof x === 'object' || typeof x === 'function')) {
    let used;
    try {
      const then = x.then;
      if(typeof then === 'function') {
        // 为什么这里使用call而不是x.then
        then.call(x, y=>{ // x为返回的新promise,y为该promise状态更改后resolve的值
          if(used) return;
          used = true;
          // 递归调用 
          resolvePromise(newPromise, y, resolve, reject);
        }, r => {
          if(used) return;
          used = true;
          reject(r);
        })
      } else {
        if(used) return; 
        used = true;
        resolve(x);
      }
    } catch (e) {
      if(used) return;
      used = true;
      reject(e);
    }
  } else {
    resolve(x);
  }
  console.log('结束', newPromise);
}

// then方法返回新的promise处理
const promise = new MyPromise((resolve, reject) => {
  setTimeout(() => resolve('Hello World'), 1000);
});
promise.then(value => {
  return new MyPromise(resolve => resolve(1))
}).then(value => console.log(value))

// resolve处理promise
const promise22 = new MyPromise((resolve) => {
  resolve(new MyPromise((resolve, reject) => {
    resolve('Hello');
  }));
});
promise22.then(value => {
  console.log(value); // 'Hello'
}).catch(error => {
  console.log(error);
});

// then resolve返回为函数的情况
const p = new MyPromise((resolve) => {
  setTimeout(() => resolve('Initial Value'), 1000);
});
p.then(value => {
  console.log(value); // 'Initial Value'
  return function() {
    console.log('This is a function returned by onFulfilled');
  };
}).then(func => {
  console.log(func);
  if (typeof func === 'function') {
    func(); // 'This is a function returned by onFulfilled'
  } else {
    console.log('Returned value is not a function');
  }
}).catch(error => {
  console.error(error);
});

const promise11 = new Promise((resolve, reject) => {
  setTimeout(() => resolve('Hello World'), 1000);
});
const promise12 = Promise.resolve(promise11)
console.log(promise11 === promise12); // true resolve如果接受promise会直接返回该promise

promise11.then(value => {
  return new Promise(resolve => resolve(1))
}).then(value => {
  console.log(value);
}).catch(error => {
  console.error(error);
});

const promise1 = new MyPromise((resolve, reject) => reject('success'))
const promise2 = new MyPromise((resolve, reject) => resolve(promise1))
console.log(promise1 === promise2); // false
promise2.then(res => console.log(res)).catch(err => console.log(err))

// then函数特点 -- 返回新的promise;原promise的状态决定新promise的状态;回调函数执行是异步的微任务;回调函数任一只能执行一次;


// ========================== 微任务实现 ========================= 
function microtask (fn, value, resolve, reject) {
  queueMicrotask(() => {
    try {
      const x = fn(value);
      resolvePromise(newPromise, x, resolve, reject);
    } catch (e) {
      reject(e);
    }
  })
}



