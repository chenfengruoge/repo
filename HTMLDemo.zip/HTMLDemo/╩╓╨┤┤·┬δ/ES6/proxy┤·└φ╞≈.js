let obj = new Proxy({}, {
  get: function (target, propKey, receiver) {
    console.log(`getting ${propKey}!`);
    return Reflect.get(target, propKey, receiver);
  },
  set: function (target, propKey, value, receiver) {
    console.log(`setting ${propKey}!`);
    return Reflect.set(target, propKey, value, receiver);
  }
});
obj.count = 1
++obj.count

// 代理对象及目标对象
let person = {
  name: "张三"
} 
let proxy = new Proxy(person, {
  get: function(target, proKey) {
    if(proKey in target) {
      return target[proKey]
    }else {
      return 'null'
    }
  }
})
console.log(proxy.name1);
proxy.name1 = '李四'
console.log(person.name,person.name1);

// 静态方法   以现有对象作为原型创建一个新对象
let childObj = Object.create(proxy)
console.log(childObj.name,childObj.name1,childObj.name2);

// get实例方法的链式调用
function pipe(value) {
  var fnArray = [] //多次拦截可以累加？ 闭包的概念 -- 函数和函数内部所能访问到的外部作用域的变量的组合;作用域 -全局作用域、函数作用域、块级作用域、声明提升 
  var proxy = new Proxy({}, {
    get: function(target, proKey) {
      if(proKey === 'get'){
        return fnArray.reduce((cur,fn) => {
          return fn(cur)
        }, value) 
      }
      fnArray.push(global[proKey])
      return proxy
    }
  })
  return proxy
}
var double = x => x * 2
var pow = x => n * n
var reverseInt = x => x.toString().split("").reverse().join("") || 0
console.log(pipe(3).double.pow.reverseInt.get);

