// 1. 7种基础类型 boolean number string  +   bigint symbol null undefine    
// 2. “包装对象” 省略原始类型值转成对象实例的麻烦
// 3.大写表字面量及包装对象两种情况，小写表示字面量
      // Boolean 和 boolean
      // String 和 string
      // Number 和 number
      // BigInt 和 bigint
      // Symbol 和 symbol
// 4.对象的大小写，小写只包含对象、数组和函数，不包括原始类型的值
// 5.值类型
{
  let x:'hello';
  x = 'hello'
}
// x = 'hello you' 类型报错
// 6.联合类型 
{
  let x:string|number;
  x = 123; // 正确
  x = 'abc'; // 正确
}
// 7.交叉类型 用于对象的合成
{
  let obj:
  { foo: string } &
  { bar: string };
  obj = {
    foo: 'hello',
    bar: 'world'
  };
}
// 8.type命令 定义一个类型的别名
{
  type Age = number;
  let age:Age = 55;
}
// 9.typeof运算符
{
  let a = 1;
  let b:typeof a; // ts typeof
  if (typeof a === 'number') { // js typeof
    b = a;
  }
}
// 10. 类型兼容性，凡是可以使用父类型的地方，都可以使用子类型
{
  let a:'hi' = 'hi'
  let b:string = 'hi';
  b = a  // 正确，因为 'hi' 可以赋值给 string
  // a = b  错误，因为 string 不可以赋值给 'hi'
}

// 数组类型 
{
  const arr = [123]; // 推断类型为 number[]
  // arr.push('abc'); 报错
}
{
  const arr: number[] = [1, 2, 3, 4, 5];
  const arr1: readonly number[] = [1, 2, 3, 4, 5]; //只读数组
}

// 元组 symol类型 函数 对象 interface(针对对象) 类 class(针对类)

// 泛型 Generics

function id<T>(arg: T): T { 
  return arg; 
}
console.log();

let myId1: <T>(arg: T) => T; //函数泛型




// this指向
class A {
  name = 'a';
  getName() {
    return this.name
  }
}
let a1 = new A();
console.log(a1.getName()); // 'a'

let b = {
  name: 'b',
  getName: a1.getName
}
console.log(b.getName());



