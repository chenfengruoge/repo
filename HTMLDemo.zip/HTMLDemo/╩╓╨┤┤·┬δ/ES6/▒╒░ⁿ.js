// 1. 闭包的概念  函数以及周围环境引用的组合，可以让函数对外部的变量进行访问
// 2. 闭包的工作原理  词法作用域、作用域链、捕获外部变量

//缓存
{
  function createClosures() {
    let count = 0
    let obj = { value: 0 }

    console.log('基础类型', count);
    console.log('引用类型', obj);

    return [
      function () {
        count++
        console.log(count);
      },
      function () {
        obj.value++
        console.log(obj.value);
      },
      function () {
        obj.value = obj.value * 2
        count = count * 2
        console.log(obj.value);
        console.log(count);
      }
    ]
  }

  const [a, b, c] = createClosures()
  a()
  b()
  c()
  createClosures()
}