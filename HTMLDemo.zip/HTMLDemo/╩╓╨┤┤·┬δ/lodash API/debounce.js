//防抖和节流

// 防抖 -- 重在清零，高频触发的事件在一段时间内只执行一次，再次触发时清零计时并重新计时。类似等电梯，来人就重新等一会。
function debounce(fn, delay) {
  let timer = null;
  return function (arguments) {
    clearTimeout(timer);
    let _this = this;
    let args = arguments;
    timer = settimeout(function() {
      fn.apply(_this, args);
    }, delay);
  }
}

const fn = x => console.log(x);
const debounceFn = debounce(fn, 1000);
debounceFn(1)
debounceFn(2)

// 节流 -- 重在加锁，高频触发的事件在一段时间内只执行一次，再次触发时需要等待上一次执行完毕后才可以执行。类似红绿灯, 绿灯亮了才可以通过。
function throttle(fn, delay) {
  let timer = null;
  return function (arguments) {
    if(timer) return;
    let _this = this;
    let args = arguments;
    timer = settimeout(function() {
      fn.apply(_this, args);
      timer = null;
    }, delay);
  }
}

const fn1 = x => console.log(x);
const throttleFn = throttle(fn1, 1000);
throttleFn(1)
throttleFn(2)