// p-limit 控制并发数

function pLimit (concurrency) {
  const queue = []; //任务队列
  let activeCount = 0; //并发数

  const next = () => { //执行下一个任务
    activeCount--;
    if (queue.length > 0) {
      queue.shift()(); //如果队列存在元素则移除 第一位的元素 并将返回的元素的 函数执行
    }
  };

  //异步函数
  const run = async (fn, resolve, args) => {
    activeCount++; //增加activeCount
    const result = (async () => fn(...args))();
    resolve(result);
    try {
      await result;
    } catch { }
    next();
  };

  const enqueue = (fn, resolve, args) => {
    queue.push(run.bind(undefined, fn, resolve, args));
    (async () => {
      // This function needs to wait until the next microtask before comparing
      // `activeCount` to `concurrency`, because `activeCount` is updated asynchronously
      // when the run function is dequeued and called. The comparison in the if-statement
      // needs to happen asynchronously as well to get an up-to-date value for `activeCount`.
      await Promise.resolve();
      if (activeCount < concurrency && queue.length > 0) {
        queue.shift()(); //run.bind(undefined, fn, resolve, args) 对应的就是执行 run(fn, resolve, args)
      }
    })();
  };

  // 生成器 -- 将异步函数压入队列
  const generator = (fn, ...args) =>
    new Promise((resolve) => {
      enqueue(fn, resolve, args);
    });
  return generator;
}

{
  const harmaxLimit = (maxCount) => {
    let activeCount = 0; 
    let waitTask = []
  
    const execute = (asyncFun, ...args) => {
      return new Promise((resolve, reject) => {
        const task = create(asyncFun, args, resolve, reject)
        if(activeCount >= maxCount) {
          waitTask.push(task)
        } else {
          task()
        }
      })
    }
  
    const create = (asyncFun, args, reslove, reject) => {
      return () => { 
        asyncFun(...args).then(reslove).catch(reject).finally(() => {
          activeCount--
          if(waitTask.length > 0) {
            waitTask.shift()()
          }
        })
        activeCount++;
      }
    }
  
    return execute;
  }

  const limit = harmaxLimit(3);
  function sleep (sec) {
    return new Promise((resolve, reject) => {
      console.log('本函数的执行时要等待' + sec + '秒')
      setTimeout(() => {
        console.log(`等待了${sec}秒执行`)
        resolve()
      }, sec * 1000)
    })
  }
  limit(sleep, 1)
  limit(sleep, 1)
  limit(sleep, 1)
  limit(sleep, 3)
  limit(sleep, 3)
  limit(sleep, 3)
}


