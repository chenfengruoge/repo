export class WebSocketClient {
  private url = '';
  private socket: WebSocket | null = null;

  constructor(url: string) {
    // super();
    this.url = url;
  }
}