Promise  “容器”  存储状态及结果   常用函数

ArrayBuffe 是啥   处理二进制数据的一段连续内存区域，不能直接读写，需要通过“视图”进行读写

dataView视图  允许不同类型的成员  实例方法  getInt8  getUnit8(读取内存中一个字节)

TypeArray视图 同一类型的类数组结构，构造函数Int8Array Unit8Array（8位的成员） +  数组方法

字节序 小端及大端

代理  proxy

模块 module
