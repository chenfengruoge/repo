- **Observable (可观察对象):** 表示一个概念，这个概念是一个可调用的未来值或事件的集合。

- **Observer (观察者):** 一个回调函数的集合，它知道如何去监听由 Observable 提供的值。

- **Subscription (订阅):** 表示 Observable 的执行，主要用于取消 Observable 的执行。

- **Operators (操作符):** 采用函数式编程风格的纯函数 (pure function)，使用像 `map`、`filter`、`concat`、`flatMap` 等这样的操作符来处理集合。

- **Subject (主体):** 相当于 EventEmitter，并且是将值或事件多路推送给多个 Observer 的唯一方式。

- **Schedulers (调度器):** 用来控制并发并且是中央集权的调度员，允许我们在发生计算时进行协调，例如 `setTimeout` 或 `requestAnimationFrame` 或其他。

1. Observable可观察对象 创建 

​    Rx.Observable.create   操作符of from等

2. Observer观察者  拥有三个回调函数的对象，对应三种通知类型

​    订阅 Observable 像是调用函数, 并提供接收数据的回调函数。

​    observable.subscribe(observer)

3. Subject主体 特殊类型`BehaviorSubject`、`ReplaySubject` 和 `AsyncSubject`
     + BehaviorSubject保存了发送给消费者的最新值。并且当有新的观察者订阅时，会立即从BehaviorSubject那接收到当前值。
     + `ReplaySubject` 记录 Observable 执行中的多个值并将其回放给新的订阅者。
     + AsyncSubject 执行完成时(complete)，它才会将执行的最后一个值发送给观察者。

4. 操作符 - - map等查手册

