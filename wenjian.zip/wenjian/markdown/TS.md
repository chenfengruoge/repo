**any类型**

>*	any、unknow（避免类型污染、限制属性及方法的访问、限制部分运算）以及never（不可能的类型，保持类型的完备性）

**类型系统**

> *	8种类型 boolean number string  +   bigint object null undefine
> *  “包装对象” 省略原始类型值转成对象实例的麻烦
> *  大写表字面量及包装对象两种情况，小写表示字面量

**泛型**